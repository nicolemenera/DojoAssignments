var money = 0.01;

for ( var day = 2; day <= 30; day++ ) {
  money *= 2;
}

console.log(money);
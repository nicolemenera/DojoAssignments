function printRange(2, 10, 2) {
  for ( var index = 2; index <= 10; index + 2 ) {
    console.log(index);
  }
}
printRange();
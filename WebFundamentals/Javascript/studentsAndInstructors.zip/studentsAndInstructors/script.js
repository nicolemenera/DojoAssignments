var students = [ 
     {first_name:  'Michael', last_name : 'Jordan'},
     {first_name : 'John', last_name : 'Rosales'},
     {first_name : 'Mark', last_name : 'Guillen'},
     {first_name : 'KB', last_name : 'Tonel'}
]

function nameOutput (arr) {
  for (var idx = 0; idx < arr.length; idx++ ) {
    console.log( arr[idx].first_name + " " + arr[idx].last_name );

  }
}

nameOutput(students);
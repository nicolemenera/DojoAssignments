// function timeAssignment (HOUR, MINUTE, PERIOD) {
//   var num = 8;
//   var 
// }


var HOUR = 8;
var MINUTE = 50;
var PERIOD = "AM";

console.log("It's currently: " + HOUR + ':' + MINUTE + ' ' + PERIOD);
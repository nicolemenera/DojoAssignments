var count = 60;

while ( count > 30 ) {
  console.log( count + " long, depressing days until my birthday :(" );
  count = count - 1;
}

while ( count <= 30 && count > 5 ) {
  console.log( count + " FRIGGIN' DAYS UNTIL MY FRIGGIN' BIRTHDAY!!!" );
  count = count - 1;
}

while ( count <= 5 && count > 1 ) {
  console.log( count + " DAYS UNTIL MY BIRTHDAY, ZOMGGG!" );
  count = count - 1;
}

while ( count === 1 ) {
  console.log( "MY BIRTHDAY IS TOMORROW!!! YEAH BOIIII!!!!!" );
  count = count - 1;
}

while ( count === 0 ) {
  console.log( " HAPPY BIRTHDAY YOU BEAUTIFUL BEAST!!!!!!!" );
}
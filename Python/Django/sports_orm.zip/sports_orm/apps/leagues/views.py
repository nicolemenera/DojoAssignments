from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

# def index(request):
# 	context = {
# 		"leagues": League.objects.all(),
# 		"teams": Team.objects.all(),
# 		"players": Player.objects.all(),
# 		return render(request, "leagues/index.html", context)

# baseball leagues
# def index(request):
# 	user = League.objects.filter(sport="Baseball")
# 	context = {
# 		"leagues": user
# 	}
# 	return render(request, "leagues/index.html", context)

# womens' league
# def index(request):
# 	user = League.objects.filter(name__contains="Womens")
# 	context = {
# 		"leagues": user
# 	}
# 	return render(request, "leagues/index.html", context)

#sport is any type of hocky
# def index(request):
# 	user = League.objects.filter(name__contains="hockey")
# 	context = {
# 		"leagues": user
# 	}
# 	return render(request, "leagues/index.html", context)
	
# all leagues except football
# def index(request):
# 	user = League.objects.exclude(sport="Football")
# 	context = {
# 		"leagues": user
# 	}
# 	return render(request, "leagues/index.html", context)

#all leagues that call themselves conferences
# def index(request):
# 	user = League.objects.filter(name__contains="Conference")
# 	context = {
# 		"leagues": user
# 	}
# 	return render(request, "leagues/index.html", context)

#all leagues in atlantic region
# def index(request):
# 	user = League.objects.filter(name__contains="Atlantic")
# 	context = {
# 		"leagues": user
# 	}
# 	return render(request, "leagues/index.html", context)

#teams based in Dallas
# def index(request):
# 	user = Team.objects.filter(location="Dallas")
# 	context = {
# 		"teams": user
# 	}
# 	return render(request, "leagues/index.html", context)

#teams names Raptors
# def index(request):
# 	user = Team.objects.filter(team_name="Raptors")
# 	context = {
# 		"teams": user
# 	}
# 	return render(request, "leagues/index.html", context)

#location includes city
# def index(request):
# 	user = Team.objects.filter(location__contains="City")
# 	context = {
# 		"teams": user
# 	}
# 	return render(request, "leagues/index.html", context)

#teams whose names begin with T
# def index(request):
# 	user = Team.objects.filter(location__startswith="T")
# 	context = {
# 		"teams": user
# 	}
# 	return render(request, "leagues/index.html", context)
	
#teams ordered alphabetically
# def index(request):
# 	user = Team.objects.order_by("location")
# 	context = {
# 		"teams": user
# 	}
# 	return render(request, "leagues/index.html", context)

#team name reverse alphabetical
# def index(request):
# 	user = Team.objects.order_by("-team_name")
# 	context = {
# 		"teams": user
# 	}
# 	return render(request, "leagues/index.html", context)

#players with last name cooper
# def index(request):
# 	user = Player.objects.filter(last_name="Cooper")
# 	context = {
# 		"players": user
# 	}
# 	return render(request, "leagues/index.html", context)

#players with first name Joshua
# def index(request):
# 	user = Player.objects.filter(first_name="Joshua")
# 	context = {
# 		"players": user
# 	}
# 	return render(request, "leagues/index.html", context)

#players with last name Cooper, excluding first name Joshua
def index(request):
	user = Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua")
	context = {
		"players": user
	}
	return render(request, "leagues/index.html", context)
	

def index(request):
	user = Player.objects.filter(first_name="Alexander")|Player.objects.filter(first_name="Wyatt")
	context = {
		"players": user
	}
	return render(request, "leagues/index.html", context)






def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
	
